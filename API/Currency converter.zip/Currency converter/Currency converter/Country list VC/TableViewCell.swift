//
//  TableViewCell.swift
//  Currency converter
//
//  Created by Harsha R Mundaragi on 11/11/22.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var code: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        
        super.setSelected(selected, animated: animated)

    }

}

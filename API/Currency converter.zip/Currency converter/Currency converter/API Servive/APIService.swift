//
//  APIService.swift
//  Currency converter
//
//  Created by Harsha R Mundaragi on 10/11/22.
//

import UIKit

class APIService: NSObject {
    
    var finalValu : Double = 0.00
    
    
    
    static let shareInstance = APIService()
    
    func getAllCountryData(completion: @escaping(CountryModel?, Error?) -> ()) {
        
        let urlString = "https://api.exchangerate.host/symbols"
        
        guard  let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url){ (data, response, error) in
            if let err = error{
                completion(nil,err)
                print("Loading data error: \(err.localizedDescription)")
            }else{
                
                guard let data = data else{ return }
                do{
                    
                    
                    let result = try JSONDecoder().decode(CountryModel.self, from: data)
                    completion(result, nil)
                    
            
                       
                }catch let jsonErr{
                    print("JSon Error: \(jsonErr.localizedDescription)")
                }
            }
            
        }.resume()
    }
    
    func callApi(button1: String, button2: String) {
    
        let urlString = "https://api.exchangerate.host/convert?from=\(button1)&to=\(button2)"

        guard  let url = URL(string: urlString) else { return }
        print(url)

        URLSession.shared.dataTask(with: url) { data, response, error in

            guard let data = data, error == nil else{
                print("somthing is wrong")
                return
            }
            
            
            var result: CalculateData?

            do{
                result = try JSONDecoder().decode(CalculateData.self, from: data)
                
            }catch{
                print("error to convets\(error.localizedDescription)")
            }
            
            guard let json = result else{
                return
            }
            
            self.finalValu = json.result
            
            
        }.resume()
    
    
        
        
    }
    
    
   


}

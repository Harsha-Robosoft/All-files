//
//  signUpVc.swift
//  Pass manager
//
//  Created by Harsha R Mundaragi on 17/10/22.
//

import UIKit

var signUpData = [SignUpDataOfUser]()

class SignUpViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var signUpMobileNumber: UITextField!
    
    @IBOutlet weak var signUpMPin: UITextField!
    
    @IBOutlet weak var signUpReEnterMPin: UITextField!
   
    @IBOutlet weak var signInButton: UIButton!
    
    var signUpUserData: SignUpDataOfUser!
    
    var iconClick: Bool = true
    
    var f = 0
  
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        CongfigureTextFields()

        ConfigureTapGesture()
        
        signUpMobileNumber.setPaddding()
        
        signUpMPin.setPaddding()
        
        signUpReEnterMPin.setPaddding()
        
        signInButton.layer.masksToBounds = true
        
        signInButton.layer.cornerRadius = 5.0

    }
    
    private func CongfigureTextFields(){

        signUpMobileNumber.delegate = self

        signUpReEnterMPin.delegate = self

    }

    private func ConfigureTapGesture(){

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(SignUpViewController.handleTap))

        view.addGestureRecognizer(tapGesture)

    }

    @objc func handleTap(){

        print("handle tap was called")

        view.endEditing(true)

    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        textField.resignFirstResponder()

        return true

    }
    
    func alertMessage(message: String){
        
            let alert = UIAlertController(title: "ALERT", message: message, preferredStyle: .alert)
        
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
            self.present(alert,animated: true, completion: nil)
        }
        
        func containsDigit(_ value: String) -> Bool
        {
            let reqularExpression = ".*[0-9]+.*"
            let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
            
            return predicate.evaluate(with: value)
        }
        
        func alertMessageforMobile(){
            
            let alert = UIAlertController(title: "ALERT", message: "Enter 10 digits only", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert,animated: true, completion: nil)
        }
    
    func alertMessageforExsistingUser(message: String){

        let alert = UIAlertController(title: "ALERT", message: message, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))

        self.present(alert,animated: true, completion: nil)

          }

    func showToast(message : String, controller: UIViewController) {

        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 90 , y: self.view.frame.size.height + 130, width: 250, height: 66))

        toastLabel.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)

        toastLabel.textColor = UIColor.white

        toastLabel.font = .systemFont(ofSize: 17.0)

        toastLabel.textAlignment = .center;

        toastLabel.text = message

        toastLabel.alpha = 1.0

        toastLabel.numberOfLines = 2

        toastLabel.layer.cornerRadius = 10;

        toastLabel.clipsToBounds  =  true

        controller.view.addSubview(toastLabel)

        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {

        toastLabel.alpha = 0.0 }, completion: {(isCompleted) in

        toastLabel.removeFromSuperview()

        })
        
    }
    
    @IBAction func signInButton(_ sender: UIButton) {
        
        view.endEditing(true)
        
        guard let number = signUpMobileNumber.text, signUpMobileNumber.text?.count != 0 else {
            
                    alertMessage(message: "Mobile Number field Should not be empty")
            
                    return
            
        }
                
                guard containsDigit(number), number.count == 10 else{
                    
                    alertMessage(message: "Enter digits not exceeding 10 charachters")
                    
                    return
                    
                }
                
        guard let pin = signUpMPin.text, signUpMPin.text?.count != 0 else {
            
                    alertMessage(message: "MPin field should not be empty")
            
                    return
            
        }
                
                guard containsDigit(pin), pin.count == 4 else{
                    
                    alertMessage(message: "Enter digits not exceeding 4 characters")
                    
                    return
                    
                }
                
        guard let reEnterMpin = signUpReEnterMPin.text, signUpReEnterMPin.text?.count != 0 else{
            
                    alertMessage(message: "Re-Enterd MPin field should not be empty")
            
                    return
            
        }
                
                guard containsDigit(reEnterMpin), reEnterMpin.count == 4 else {
                    
                    alertMessage(message: "Enter digits not exceeding 4 characters")
                    
                    return
                    
                }
                
        guard pin == signUpReEnterMPin.text else {
                    
                    alertMessage(message: "Re-Entered MPin does not match Mpin")
                    return
        }
        
        for i in signUpData{
            
        if( i.userMobileNumber == signUpMobileNumber.text) {

            f = 1

            alertMessageforExsistingUser(message: "You are already Signed In")

            break;

            }
            
        }
        
        if (f == 0) {
            
        _ = UIStoryboard(name: "Main", bundle: nil)
        
        let currentLogin = SignUpDataOfUser(userMobileNumber: number, userMPin: pin)
        signUpData.append(currentLogin)
        
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("values.txt")
        
        do {
            
            let data = try NSKeyedArchiver.archivedData(withRootObject: signUpData, requiringSecureCoding: false)
            
            try data.write(to: path)
            
        }
        catch {
            
            print("ERROR: \(error.localizedDescription)")
            
        }

        let signUpVc1 = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        
        self.showToast(message: "Congrats..!!! you are Signed Up", controller: signUpVc1)
        
        self.navigationController?.pushViewController(signUpVc1, animated: true)
            
        }
    }
    
    @IBAction func showMPin(_ sender: Any) {
        
        if (iconClick){
            
            signUpReEnterMPin.isSecureTextEntry = false
            
        }
        else{
            
            signUpReEnterMPin.isSecureTextEntry = true
            
        }
        
        iconClick = !iconClick
        
    }
        
}
    
    
    





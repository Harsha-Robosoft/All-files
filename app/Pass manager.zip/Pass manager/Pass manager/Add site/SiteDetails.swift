//
//  SiteDetails.swift
//  Pass manager
//
//  Created by Harsha R Mundaragi on 19/10/22.
//

//import Foundation
//import UIKit
//
//class Sitedetails
//{
//    var url: String
//    var siteName: String
//    var sector_folder: String
//    var password: String
//    var note: String
//    var logo: UIImage
//    
//    init(url: String, siteName: String, sector_folder: String, password: String, note: String, logo: UIImage) {
//        self.url = url
//        self.siteName =  siteName
//        self.sector_folder = sector_folder
//        self.password = password
//        self.note = note
//        self.logo = logo
//    }
//    
//  
//    
//}
